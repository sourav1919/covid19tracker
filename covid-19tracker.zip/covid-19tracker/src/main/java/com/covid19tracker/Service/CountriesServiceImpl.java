package com.covid19tracker.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.covid19tracker.DAO.CountriesDAO;
import com.covid19tracker.DAO.DaywiseDAO;
import com.covid19tracker.Model.Countries;
import com.covid19tracker.Model.Daywise;

@Service
public class CountriesServiceImpl implements CountriesService {

	@Autowired
	private CountriesDAO countriesDAO;
	
	@Autowired
	private DaywiseDAO daywiseDAO;
	
	@Override
	@Transactional
	public void setAll(List<Countries> listCountries) {
		countriesDAO.setAll(listCountries);

	}
	
	@Override
	@Transactional
	public List<Countries> getAllRecovered() {
		return countriesDAO.getAllRecovered();
	}
	
	@Override
	@Transactional
	public List<Countries> getAllDeaths() {
		return countriesDAO.getAllDeaths();
	}

	@Override
	@Transactional
	public List<Countries> getAllActive() {
		return countriesDAO.getAllActive();
	}

	@Override
	@Transactional
	public void setAllDaywise(List<List<Daywise>> listOfListDaywise) {
		System.out.println("****************in service******************");
		daywiseDAO.setAllDaywise(listOfListDaywise);
		System.out.println("****************out service******************");
	}

}
