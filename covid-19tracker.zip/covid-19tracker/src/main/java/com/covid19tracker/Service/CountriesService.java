package com.covid19tracker.Service;

import java.util.List;
import com.covid19tracker.Model.Countries;
import com.covid19tracker.Model.Daywise;

public interface CountriesService {
	public void setAll(List<Countries> listCountries);
	
	public List<Countries> getAllActive();
	
	public List<Countries> getAllRecovered();
	
	public List<Countries> getAllDeaths();

	public void setAllDaywise(List<List<Daywise>> listOfListDaywise);
}
