package com.covid19tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class Covid19trackerApplication{
	
	public static void main(String[] args) throws Exception{
		SpringApplication.run(Covid19trackerApplication.class, args);
		//System.out.println("Hello World");
	}
}
