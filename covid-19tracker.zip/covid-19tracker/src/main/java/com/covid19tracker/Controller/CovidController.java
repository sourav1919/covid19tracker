package com.covid19tracker.Controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.covid19tracker.Driver.Driver;
import com.covid19tracker.Driver.DriverCountriesImpl;
import com.covid19tracker.Driver.DriverDaywiseImpl;
import com.covid19tracker.Model.Countries;
import com.covid19tracker.Model.Daywise;
import com.covid19tracker.Service.CountriesService;

@RestController
@RequestMapping("/Details")
public class CovidController {
	
	@Autowired
	private CountriesService countriesService;
	private List<Countries> listCountries;
	
	@PostConstruct
	public void setAll()
	{
		//System.out.println("***********in controller***************");
		
		DriverCountriesImpl driverObject1=new DriverCountriesImpl();
		listCountries=driverObject1.driverCountries();
		countriesService.setAll(listCountries);
		//System.out.println("*********out of controller**********");

		System.out.println("***********in controller***************");
		DriverDaywiseImpl driverObject2=new DriverDaywiseImpl();
		List<List<Daywise>> listOfListDaywise=driverObject2.driverDaywise();
		countriesService.setAllDaywise(listOfListDaywise);
		System.out.println("*********out of controller**********");
		
	}
	@GetMapping("/Daywise")
	public List<List<Daywise>> setAllDaywise()
	{
		DriverDaywiseImpl driverObject2=new DriverDaywiseImpl();
		List<List<Daywise>> listOfListDaywise=driverObject2.driverDaywise();
		return listOfListDaywise;
	}
	
	@GetMapping("/Active")
	public List<Countries> getAllActive()
	{
		listCountries=countriesService.getAllActive();
		return listCountries;
	}
	@GetMapping("/Recovered")
	public List<Countries> getAllRecovered()
	{
		listCountries=countriesService.getAllRecovered();
		return listCountries;
	}
	@GetMapping("/Deaths")
	public List<Countries> getAllDeaths()
	{
		listCountries=countriesService.getAllDeaths();
		return listCountries;
	}
	
}
