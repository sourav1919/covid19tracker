package com.covid19tracker.Model;

import java.util.List;

import javax.persistence.Embeddable;

@Embeddable
public class Details {
	private String dates;
	private String cases;
	private String deaths;
	private String recovered;
	
	

	

}
