package com.covid19tracker.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Daywise {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String country;
	private String dates;
	private String cases;
	private String deaths;
	private String recovered;	
	
	public Daywise() {
	}
	public Daywise(String country, String dates, String cases, String deaths, String recovered) {
		this.country = country;
		this.dates = dates;
		this.cases = cases;
		this.deaths = deaths;
		this.recovered = recovered;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public String getCases() {
		return cases;
	}
	public void setCases(String cases) {
		this.cases = cases;
	}
	public String getDeaths() {
		return deaths;
	}
	public void setDeaths(String deaths) {
		this.deaths = deaths;
	}
	public String getRecovered() {
		return recovered;
	}
	public void setRecovered(String recovered) {
		this.recovered = recovered;
	}
	@Override
	public String toString() {
		return "Daywise [country=" + country + ", dates=" + dates + ", cases=" + cases + ", deaths=" + deaths
				+ ", recovered=" + recovered + "]";
	}
	
	
	
	

	
	
	
	
}
