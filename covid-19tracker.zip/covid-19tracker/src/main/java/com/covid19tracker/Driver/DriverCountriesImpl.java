package com.covid19tracker.Driver;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.covid19tracker.Model.Countries;
import com.covid19tracker.Service.CountriesService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;


public class DriverCountriesImpl {
	
	List<Countries> list;
	public List<Countries> driverCountries()
	{
		//System.out.println("***********in driver***********");
	try {	
		String url = "https://corona.lmao.ninja/v2/countries";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        con.connect();
        int responseCode=con.getResponseCode();
        StringBuffer response = new StringBuffer();
        if(responseCode!=200)
        	throw new RuntimeException("HttpResponseCode"+responseCode);        
        else
        { 
        	BufferedReader in = new BufferedReader(
        			new InputStreamReader(con.getInputStream()));
        	String inputLine;
        
        	while ((inputLine = in .readLine()) != null)
        	{
        		response.append(inputLine);
        	}
        	in .close();
        }
       // System.out.println(response.toString());
        
        ObjectMapper mapper=new ObjectMapper();
        list=mapper.readValue(response.toString(), TypeFactory.defaultInstance().constructCollectionType(List.class, Countries.class));
 /*       
        for(Countries countries: list)
        {
        	System.out.println("Country: "+countries.getCountry());
        	System.out.println("Cases: "+countries.getCases());
        	System.out.println("TodayCases: "+countries.getTodayCases());
        	System.out.println("Deaths: "+countries.getDeaths());
        	System.out.println("Recovered: "+countries.getRecovered());
        	System.out.println("TodayRecovered: "+countries.getTodayRecovered());
        	System.out.println("Active: "+countries.getActive());
        	System.out.println("*************");
        }
        System.out.println("Number of countries: "+list.size());
*/        
	}
    catch (Exception e) {
        e.printStackTrace();
    }
	//System.out.println("**************out of driver*********************");
	return list;
	}

}
