package com.covid19tracker.Driver;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.covid19tracker.Model.Daywise;
import com.covid19tracker.Model.Details;

public class DriverDaywiseImpl{
	int lo=0;
	private StringBuffer response=new StringBuffer();
	
	private List<List<Daywise>> listOfListDaywise=new ArrayList<List<Daywise>>();
	
	public List<List<Daywise>> driverDaywise()
	{
		//********************* Reading JSON data from URL and getting String***************
		try
		{
		String url="https://corona.lmao.ninja/v3/covid-19/historical";
		URL o=new URL(url);
		HttpURLConnection con=(HttpURLConnection) o.openConnection();
		con.setRequestMethod("GET");
		con.connect();
		int responseCode=con.getResponseCode();
		
		if(responseCode!=200)
			throw new RuntimeException(" Http response Code: "+responseCode);
		else
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			while((inputLine=br.readLine()) != null)
			{
				response.append(inputLine);
			}
		//System.out.println(response.toString());
		}
		
		Object obj=new JSONParser().parse(response.toString());
		
		JSONArray ja= (JSONArray) obj;
		lo=ja.size();
		System.out.println(" Number of countries ="+ja.size());
		
		JSONObject joCountry;
		JSONObject joTimeline;
		List<String> listCountry;
		listCountry=new ArrayList<>();	
		List<String> listCases;
		List<String> listDates;
		List<String> listRecovered;
		List<String> listDeaths;
		
		for(int i=0; i<ja.size(); i++)
		{	
			joCountry=(JSONObject) ja.get(i);
			
			// *****************Storing country data in Daywise*******************
			
					
			listCountry.add(joCountry.get("country").toString());
			
			joTimeline= (JSONObject) joCountry.get("timeline");
			
			//********************Converting JSONObject to Map*****************
			
			Map cases=((Map)joTimeline.get("cases"));			
			Iterator<Map.Entry> itr1= cases.entrySet().iterator();
			
			//*********************Storing date and case data******************
			
			listCases=new ArrayList<String>();			
			listDates=new ArrayList<String>();
			
			while(itr1.hasNext())
			{
				Map.Entry pair=itr1.next();						
				listDates.add(pair.getKey().toString());				
				listCases.add(pair.getValue().toString());
			}
			
			Map recovered=(Map) joTimeline.get("recovered");
			Iterator<Map.Entry> itr2= recovered.entrySet().iterator();
			
			// ************************Storing recovered data ************************
			
			listRecovered=new ArrayList<String>();
			
			while(itr2.hasNext())
			{
				Map.Entry pair=itr2.next();			
				listRecovered.add(pair.getValue().toString());
			}
			
			Map deaths=(Map) joTimeline.get("deaths");			
			Iterator<Map.Entry> itr3=deaths.entrySet().iterator();
			
			//******************************Storing death data*********************		
			
			listDeaths=new ArrayList<String>();			
			while(itr3.hasNext())
			{
				Map.Entry pair=itr3.next();			
				listDeaths.add(pair.getValue().toString());
			}
			System.out.println("i= "+i);
			List<Daywise> listDaywise=storeModel( i, listCountry, listDates, listCases, listRecovered, listDeaths);
			listOfListDaywise.add(listDaywise);
		}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}		
		return listOfListDaywise;
		
	}
	
	public List<Daywise> storeModel(int i, List<String> listCountry, List<String> listDates, List<String> listCases, List<String> listRecovered, List<String> listDeaths)
	{
		List<Daywise> listDaywise=new ArrayList<Daywise>();		
		Daywise[] daywise=new Daywise[lo];
		
		for(int j=0; j<listDates.size(); j++)
		{
			daywise[j]=new Daywise();
			daywise[j].setCountry(listCountry.get(i));
			daywise[j].setCases(listCases.get(j));
			daywise[j].setDates(listDates.get(j));
			daywise[j].setRecovered(listRecovered.get(j));
			daywise[j].setDeaths(listDeaths.get(j));
			listDaywise.add(daywise[j]);
		}
		
		return listDaywise;
		
/*		for(int j=0; j<listDates.size(); j++)
			{
				System.out.println("Country: "+listCountry.get(i));
				System.out.println("Dates: "+listDates.get(j));
				System.out.println("Cases: "+listCases.get(j));
				System.out.println("Recovered: "+listRecovered.get(j));
				System.out.println("Deaths: "+listDeaths.get(j));
				System.out.println("*******************");
			}
*/		
	}
}
