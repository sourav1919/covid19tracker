package com.covid19tracker.DAO;

import java.util.List;

import com.covid19tracker.Model.Daywise;

public interface DaywiseDAO {
	public void setAllDaywise(List<List<Daywise>> listOfListDaywise);
}
