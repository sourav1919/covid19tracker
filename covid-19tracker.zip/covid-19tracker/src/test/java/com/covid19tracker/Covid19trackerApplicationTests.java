package com.covid19tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Covid19trackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
